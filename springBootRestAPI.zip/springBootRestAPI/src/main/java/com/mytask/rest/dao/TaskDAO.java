package com.mytask.rest.dao;

import org.springframework.stereotype.Repository;

import com.mytask.rest.model.Task;
import com.mytask.rest.model.Tasks;

@Repository
public class TaskDAO 
{
    private static Tasks list = new Tasks();
    
    static 
    {
        list.getTaskList().add(new Task(1, "Design", "1",1, "05-03-2019","10-03-2019"));
        list.getTaskList().add(new Task(2, "Coding", "1",2, "15-03-2019","25-03-2019"));
        list.getTaskList().add(new Task(3, "UbitTesting", 3,"1", "25-03-2019","30-03-2019"));
    }
    
    public Tasks getAllTasks() 
    {
        return list;
    }
    
    public void addTask(Task task) {
        list.getTaskList().add(task);
    }
}
