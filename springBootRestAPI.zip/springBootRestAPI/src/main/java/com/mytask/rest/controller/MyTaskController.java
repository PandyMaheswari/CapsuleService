package com.mytask.rest.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.mytask.rest.dao.TaskDAO;
import com.mytask.rest.model.Task;
import com.mytask.rest.model.Tasks;

@RestController
@RequestMapping(path = "/mytask")
public class MyTaskController 
{
    @Autowired
    private TaskDAO taskDao;
    
    @GetMapping(path="/", produces = "application/json")
    public Tasks getTasks() 
    {
        return taskDao.getAlTasks();
    }
    
    @PostMapping(path= "/", consumes = "application/json", produces = "application/json")
    public ResponseEntity<Object> addTask(
                        @RequestHeader(name = "X-COM-PERSIST", required = true) String headerPersist,
                        @RequestHeader(name = "X-COM-LOCATION", required = false, defaultValue = "ASIA") String headerLocation,
                        @RequestBody Task task) 
                 throws Exception 
    {       
        //Generate resource id
        Integer id = taskDao.getAllTasks.geTaskList().size() + 1;
        task.setId(id);
        
        //add resource
        taskDao.addTask(task);
        
        //Create resource location
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                                    .path("/{id}")
                                    .buildAndExpand(task.getId())
                                    .toUri();
        
        //Send location in response
        return ResponseEntity.created(location).build();
    }
}
