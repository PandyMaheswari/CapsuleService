package com.mytask.rest.model;

public class Task {

    public Task() {

    }

    public Task(Integer id, String taskName, String parentTask, Integer priority, Date startDate,Date endDate) {
        super();
        this.id = id;
        this.taskName = taskName;
        this.parentTask = parentTask;
        this.startDate = startDate;
		 this.endDate = endDate;
    }
 
    private Integer id;
	private Integer priority;
    private String taskName;
    private String parentTask;
	private Date startDate;
	private Date endDate;
  
   public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }
	
	
	   public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String gettaskName() {
        return taskName;
    }

    public void settaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getparentTask() {
        return parentTask;
    }

    public void setparentTask(String parentTask) {
        this.parentTask = parentTask;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @Override
    public String toString() {
        return "Task [id=" + id + ", taskName=" + taskName + ", parentTask=" + parentTask + ", priority=" + priority + "]";
    }
}
